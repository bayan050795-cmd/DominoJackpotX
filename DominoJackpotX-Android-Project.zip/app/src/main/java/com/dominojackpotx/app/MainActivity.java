package com.dominojackpotx.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    int spins = 0, wins = 0, chips = 10000;
    TextView stats, result, advice;
    EditText betInput;
    Random random = new Random();

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    void addSpace(LinearLayout l, int h) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.BLACK); b.setTextSize(15); b.setTypeface(null, Typeface.BOLD);
        b.setBackground(bg(Color.rgb(0,229,168), 14));
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,13,22));
        getWindow().setNavigationBarColor(Color.rgb(9,13,22));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(9,13,22));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(root);

        TextView brand = text("DOMINO JACKPOT X", 24, Color.rgb(0,229,168), true);
        root.addView(brand);
        root.addView(text("OFFLINE GAME ANALYZER  •  SIMULATOR", 11, Color.LTGRAY, true));
        addSpace(root, 20);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(16),dp(16),dp(16),dp(16));
        panel.setBackground(bg(Color.rgb(20,28,43),18)); root.addView(panel);
        panel.addView(text("SIMULASI CHIP", 13, Color.LTGRAY, true));
        addSpace(panel, 6);
        stats = text("", 21, Color.WHITE, true); panel.addView(stats); updateStats();

        addSpace(root, 18);
        root.addView(text("NILAI TARUHAN SIMULASI", 12, Color.LTGRAY, true));
        betInput = new EditText(this); betInput.setSingleLine(true);
        betInput.setInputType(2); betInput.setText("100");
        betInput.setTextColor(Color.WHITE); betInput.setHintTextColor(Color.GRAY);
        betInput.setHint("Masukkan chip"); betInput.setPadding(dp(14),0,dp(14),0);
        betInput.setBackground(bg(Color.rgb(20,28,43),12));
        root.addView(betInput, new LinearLayout.LayoutParams(-1,dp(52)));

        addSpace(root, 12);
        Button spin = button("JALANKAN 1 PUTARAN SIMULASI");
        root.addView(spin, new LinearLayout.LayoutParams(-1,dp(54)));
        spin.setOnClickListener(v -> runSpin());

        addSpace(root, 12);
        Button reset = button("RESET SIMULASI");
        reset.setBackground(bg(Color.rgb(47,61,81),14)); reset.setTextColor(Color.WHITE);
        root.addView(reset, new LinearLayout.LayoutParams(-1,dp(48)));
        reset.setOnClickListener(v -> { spins=0; wins=0; chips=10000; result.setText("Simulasi direset."); advice.setText("Mulai simulasi baru kapan saja."); updateStats(); });

        addSpace(root, 18);
        LinearLayout out = new LinearLayout(this);
        out.setOrientation(LinearLayout.VERTICAL); out.setPadding(dp(16),dp(16),dp(16),dp(16));
        out.setBackground(bg(Color.rgb(20,28,43),18)); root.addView(out);
        out.addView(text("HASIL PUTARAN", 13, Color.LTGRAY, true));
        addSpace(out, 8);
        result = text("Belum ada putaran.", 18, Color.WHITE, true); out.addView(result);
        addSpace(out, 8);
        advice = text("Catatan: simulasi ini acak dan tidak membaca atau mengubah hasil game asli.", 13, Color.rgb(185,198,215), false);
        out.addView(advice);

        addSpace(root, 18);
        root.addView(text("PENTING", 13, Color.rgb(0,229,168), true));
        addSpace(root, 5);
        root.addView(text("Aplikasi ini hanya simulator offline. Tidak terhubung ke Higgs Domino, tidak menyediakan auto jackpot, kebal kalah, bot, atau manipulasi server. Hasil simulasi bukan prediksi hasil permainan asli.", 12, Color.LTGRAY, false));

        setContentView(scroll);
    }

    void updateStats() {
        if (stats != null) stats.setText("Chip: " + chips + "     Putaran: " + spins + "     Menang: " + wins);
    }

    void runSpin() {
        int bet;
        try { bet = Integer.parseInt(betInput.getText().toString()); }
        catch(Exception e) { bet = 0; }
        if (bet <= 0) { result.setText("Masukkan taruhan yang valid."); return; }
        if (bet > chips) { result.setText("Chip simulasi tidak cukup."); return; }
        spins++;
        // Simulated odds only; not connected to the real game's mechanics.
        boolean win = random.nextInt(100) < 35;
        if (win) {
            wins++; chips += bet;
            result.setText("MENANG SIMULASI  +" + bet + " chip");
            advice.setText("Hasil acak simulasi. Ini bukan sinyal jackpot atau prediksi game asli.");
        } else {
            chips -= bet;
            result.setText("KALAH SIMULASI  -" + bet + " chip");
            advice.setText("Hasil acak simulasi. Pertimbangkan berhenti jika batas chip tercapai.");
        }
        updateStats();
    }
}
